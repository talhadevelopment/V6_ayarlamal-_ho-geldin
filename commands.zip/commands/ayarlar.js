module.exports = {
  name:"ayarlar" ,
  aliases:["settings"],
  code:`
  $author[$username[$clientID]|Ayarlar Sistemi]
  $description[✅|❌ HG BB : **$getGuildVar[hgbb]**
📙|HG BB Kanal :** <#$getGuildVar[hgbbkanal]>**
<a:hosgeldin:1189990168992681994>HG Mesajı : **$getGuildVar[hgmesaj]**
 <a:bb:1190000702165094523>BB Mesajı : **$getGuildVar[bbmesaj]**]
$color[Random]
$footer[$username kullandı.]

  `
}
