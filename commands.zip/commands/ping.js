module.exports = {
name: "ping" ,
  code: `
  $author[$username[$clientID]|Ping]
  $description[## __Bot Gecikmeleri__
  Bot Ping : **$pingms**
  Mesaj Ping : **$messagePingms**
  Komut Ping : **$executionTimems**]
  $color[Random]
  $footer[$username[$clientID]|Ping]
  $addTimestamp`
}
